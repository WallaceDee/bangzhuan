export { default } from './BzFooter.vue'
