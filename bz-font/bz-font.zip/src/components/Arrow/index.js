export { default } from './Arrow.vue'
